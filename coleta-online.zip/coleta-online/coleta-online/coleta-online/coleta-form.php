<?php
session_start();

if(empty($_SESSION['token'])){
    
    header('Location: index.html');
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="COLETA ON LINE">

    <!-- Title Page-->
    <title>RÁPIDO FIGUEIREDO - COLETA ON LINE</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
</head>

<body>
    <div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
        <div class="wrapper wrapper--w960">
            <div class="card card-4">
                <div class="card-body">
                    
                <center>
                         <a href="http://www.rapidofigueiredo.com.br"> <img src="https://rapidofigueiredo.com.br/wp-content/uploads/2020/08/logo-rapido.png"></a>  
<br>
                    <h2 class="title">COLETA ON LINE - ACESSO</h2>
                    </center>
                
                

                    <h5>Por favor preencha todos os dados corretamente.<br><br></h3>
                    <form method="POST" action="coleta-on-line-gw-enviado.php" >
                    <h3>1 - Dados do Remetente</h3>
                        <div class="row row-space">
                        


                        
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label"><b>NOME</b></label>
                                    <input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="nomeremetente" id="nomeremetente">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label><b>BASE PARA COLETA *</b></label> <br> <b>SÃO PAULO</b>
								    <input type="hidden"  value="SPO" maxlength="100" class="form-control" name="base" id="base" readonly="readonly">
                                  
                                </div>
                            </div>




                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label"><b>CPF / CNPJ: *</b></label>
									<input type="text"  class="input--style-4" required="required" value="" maxlength="100"  name="cnpj" id="cnpj">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label"><b>EMAIL</b></label>
                                    <input type="email"  required="required" value="" maxlength="100" class="input--style-4" name="emailRemetente" id="emailRemetente">
                                </div>
                            </div>

                                            <div class="col-2">
                                            <label class="label"><b>Endereço *</b></label>
												<input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="enderecoRemetente" id="enderecoRemente">
											</div>
                     
											<div class="col-2">
                                            <label class="label"><b>Bairro *</b></label>
												<input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="bairroRemetente" id="bairroRemetente">
											</div>
					 
											<div class="col-2">
                                            <label class="label"><b>Cidade *</b></label>
												<input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="cidadeRementente" id="cidadeRemetente">
											</div>
											
											<div class="col-2">
												<label class="label"><b>Estado *</b></label>
												<input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="estadoRementente" id="estadoRementente">
											</div>
											<div class="col-2">
                                            <label class="label"><b>CEP *</b></label>
												<input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="cepRemtente" id="cepRemetente">
                                            </div>


                                            
                                            
                            
                        </div>
                        
                        
                        <br><br>
                        <hr>
                        <br><br>

                    <h3>2 - Dados da carga</h3>
                    <div class="row row-space">     
                        
                            <div class="col-3">
                                <div class="input-group">
                                <label class="label"><b>Altura:*</b></label>
												<input type="number"  required="required" value="" maxlength="100" class="input--style-4" name="altura" id="altura">
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">
                                <label class="label"><b>Largura *</b></label>
								<input type="number"  required="required" value="" maxlength="100" class="input--style-4" name="largura" id="largura">
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">
                                <label class="label"><b>Comprimento *</b></label>
								<input type="number"  required="required" value="" maxlength="100" class="input--style-4" name="comprimento" id="comprimento">
                                </div>
                            </div>
                            <div class="col-3">
                                <div class="input-group">
                                <label class="label"><b>Unidade de medida *</b></label>				
												<select class="input--style-4" required="required" name="DimensoesMedida" id="DimensoesMedida" >
												<option></option>
												<option value="Centimetros">Cent&iacute;metros</option>
												<option value="Metros">Metros</option>
												</select>
                                </div>
                            </div>

                            <div class="col-3">
                                <div class="input-group">
                                <label class="label"><b>Quantidade de volumes:*</b></label>
								<input type="number"  required="required" value="" maxlength="100" class="input--style-4" name="quantidade" id="quantidade">


                                </div>
                            </div>


                            <div class="col-3">
                                <div class="input-group">
                                <label class="label"><b>Peso total *</b></label>
								<input type="number"  required="required" value="" maxlength="100" class="input--style-4" name="pesototal" id="pesototal">   

                                
                                </div>
                            </div>


                            <div class="col-3">
                                <div class="input-group">
                                <label class="label"><b>Comprimento *</b></label>
								<input type="number"  required="required" value="" maxlength="100" class="input--style-4" name="comprimento" id="comprimento">  
                                </div>
                            </div>


                            <div class="col-3">
                                <div class="input-group">
                                <label class="label"><b>Tipo de volume:*</b></label>
												
												<select class="input--style-4" required="required" name="tipovolume" id="tipovolume" >
												<option></option>
												<option value="fardos">Fardos</option>
												<option value="caixas">Caixas</option>
												<option value="tambores">Tambores</option>
												<option value="bambonas">Bambonas</option>
												</select>
                                </div>
                            </div>



                            <div class="col-3">
                                <div class="input-group">
                                										
                                <label class="label"><b>Outros (especificar):</b></label>
								<input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="outros" id="outros">
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="input-group">
                                <label class="label"><b>Valor da nota:*</b></label>
								<input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="ValorNota" id="ValorNota">



                                </div>
                            </div>


                            <div class="col-md-3">
                                <div class="input-group">

                                <label class="label"><b>Modalidade de frete*</b></label>
												
                                <select class="input--style-4" required="required" name="modalidade" id="modalidade" >
												<option></option>
												<option value="A pagar">A pagar</option>
								<option value="Pago">Pago</option>
												</select>

                                </div>
                            </div>


                            <div class="col-md-3">
                                <div class="input-group">
                               
                                <label class="label"><b>Observação</br></label>
                                <textarea  class="input--style-4" name="observacao" ></textarea>


                                </div>
                            </div>


                    </div>

                    
                    <h3>3 - Dados do destinatário</h3>
                        <div class="row row-space">
                        


                        
                                    <div class="col-2">
                                        <div class="input-group">
                                            <label class="label"><b>Nome destinatário</b></label>
                                            
                                            <input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="nomeDestinatario" id="nomeDestinatario">
                                        
                                        </div>
                                    </div>
                            
                            
                                    <div class="col-2">
                                        <div class="input-group">
                                        <label class="label"><b>CPF / CNPJ*</b></label>
                                        <input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="cnpjDestinatario" id="cnpjDestinatario">
                                        </div>
                                    </div>

                        



                                    <div class="col-3">
                                        <div class="input-group">
                                            <label class="label"><b>Email</b></label>
                                            
                                            <input type="email"  required="required" value="" maxlength="100" class="input--style-4" name="emailDestinatario" id="emailDestinatario">
                                        
                                        </div>
                                    </div>



                                    <div class="col-3">
                                        <div class="input-group">
                                         <label class="label"><b>Endereço*</b></label>
                                        <input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="endereco" id="endereco">
                                        </div>
                                     </div>


                                     <div class="col-3">
                                        <div class="input-group">
                                         <label class="label"><b>Bairro*</b></label>
                                         <input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="bairro" id="bairro">
                                        </div>
                                     </div>

                                     <div class="col-3">
                                        <div class="input-group">
                                         <label class="label"><b>Cidade*</b></label>
                                         <input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="cidade" id="cidade">
                                        </div>
                                     </div>

                                     <div class="col-3">
                                        <div class="input-group">
                                         <label class="label"><b>Estado*</b></label>
                                         <input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="estadoDestinatario" id="estadoDestinatario">
                                        </div>
                                     </div>


                                     <div class="col-3">
                                        <div class="input-group">
                                         <label class="label"><b>CEP*</b></label>
                                         <input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="cepDestinatario" id="cepDestinatario">
                                        </div>
                                     </div>


                                     <div class="col-2">
                                        <div class="input-group">
                                         <label class="label"><b>Telefone*</b></label>
                                         <input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="telefone" id="telefone">
                                        </div>
                                     </div>

                                     <div class="col-2">
                                        <div class="input-group">
                                         <label class="label"><b>Contato*</b></label>
                                         <input type="text"  required="required" value="" maxlength="100" class="input--style-4" name="contato" id="contato">
                                        </div>
                                     </div>



                        </div>
                         
                         
                         

                        









                        <br><br>
                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="submit">ENVIAR SOLICITAÇÃO</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->