<?php
session_start();

$login = $_POST['login'];
$senha = $_POST['senha'];


// Iniciamos a função do CURL:


$url = 'http://gwfiscal.gwcloud.com.br/webresources/v2/servicosGW/solicitarToken';
$curl = curl_init($url);
curl_setopt_array($curl, 
                array( CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CUSTOMREQUEST => "GET", 
    
                CURLOPT_HTTPHEADER => array(
                    "login: $login",
                    "senha: $senha",
                    "GUID: 551235b5-b769-409c-9ce3-ba37d19ddc0e"
                ),


                )

);

$return = curl_exec($curl);
curl_close($curl);

// echo $return; // a tua resposta em string json
$arrResp = json_decode($return, true); // o teu array criado a partir do json de resposta

$token = $arrResp[token];

if ($arrResp[codigo] =='001') { 

    
    
    
    echo "<script>";
    echo "window.alert('USUÁRIO OU SENHA NÃO ENCONTRADOS');";
    echo "document.location='https://rapidofigueiredo.com.br/coleta-online'";
    echo "</script>";
    echo "<script></script>";
    



    

    // header('Location: https://rapidofigueiredo.com.br/coletanovo/"');

    

    

} else {

    // echo "Acesso Permitido";
    $_SESSION['token'] = $token;
    $_SESSION['emailRemente'] = $emailRemente;
    // header('Location: form-coleta.php');
    // header('Location: ../coleta-on-line-gw.php');
    echo "<script>document.location='coleta-form.php'</script>";

    
}

// echo $_SESSION['token'];

?>

