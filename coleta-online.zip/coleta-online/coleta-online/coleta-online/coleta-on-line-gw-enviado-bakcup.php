<?php
header("Content-Type: text/html; charset=UTF-8",true);
session_start();

if(empty($_SESSION['token'])){
    
    header('Location: ../area-do-cliente2.php');
}

$token = $_SESSION['token'];

/*
foreach ($_POST as $campo => $valor) { 
     $$campo = $valor;

  echo "<p>";  
  echo $post[$$campo]=$valor;
  echo "</p>";
 


 $dados = $post[$$campo]=$valor;

// echo "post['$campo'] = POST_[$campo]; <br>";

}
*/
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>Au Register Forms by Colorlib</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
</head>

<body>
    <div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
        <div class="wrapper wrapper--w960">
            <div class="card card-4">
                <div class="card-body">
                    <center>
                    <h2 class="title">COLETA ON LINE - ACESSO</h2>
                    </center>



                    <?php

//API DO GATEWAY


$post['endereco']   = $_POST[enderecoRemetente];
$post['bairro']     = $_POST[bairroRemetente];
$post['cidade']     = $_POST[cidadeRementente];
$post['contato']    = $_POST[contatoRemetente];
$post['setor']      = "NAO IDENTIFICADO";
$post['telefone']   = $_POST[telefoneRemetente];
$post['qtdVolumes'] = $_POST[quantidade];
$post['pesoVolume'] = $_POST[pesototal];

// restante dos campos vindo do formulário

$post['informacoesComplementares'] = 'Nome remetente:'.$_POST[nomeremetente]. '&#10;';
$post['informacoesComplementares'] .= 'Base:'.$_POST[base]. '&#10;';
$post['informacoesComplementares'] .= 'CNPJ:'.$_POST[cnpj]. '&#10;';
$post['informacoesComplementares'] .= 'EMAIL Remetente:'.$_POST[emailRemetente]. '&#10;';
$post['informacoesComplementares'] .= 'Estado:'.$_POST[estadoRementente]. '&#10;';
$post['informacoesComplementares'] .= 'CEP:'.$_POST[cepRemtente]. '&#10;';
$post['informacoesComplementares'] .= 'Altura: '.$_POST[altura].' &#10;';
$post['informacoesComplementares'] .= 'Largura: '.$_POST[largura].' &#10;';
$post['informacoesComplementares'] .= 'Comprimento: '.$_POST[comprimento].' &#10;';
$post['informacoesComplementares'] .= 'Dimensão: '.$_POST[DimensoesMedida].' &#10;';
$post['informacoesComplementares'] .= 'Tipo: '.$_POST[tipovolume].' &#10;';
$post['informacoesComplementares'] .= 'Email: '.$_POST[emailDestinatario].' &#10;';
$post['informacoesComplementares'] .= 'Estado: '.$_POST[estadoRementente].' &#10;';
$post['informacoesComplementares'] .= 'CEP: '.$_POST[cepRemtente].' &#10;';
$post['informacoesComplementares'] .= 'Altura: '.$_POST[altura].' &#10;';
$post['informacoesComplementares'] .= 'Largura: '.$_POST[largura].' &#10;';
$post['informacoesComplementares'] .= 'Comprimento: '.$_POST[comprimento].' &#10;';
$post['informacoesComplementares'] .= 'Dimensão: '.$_POST[DimensoesMedida].' &#10;';
$post['informacoesComplementares'] .= 'Tipo: '.$_POST[tipovolume].' &#10;';
$post['informacoesComplementares'] .= 'Outros: '.$_POST[outros].' &#10;';


 $post['valorNota'] = $_POST[valor];


$post['informacoesComplementares'] .= 'Nota Fiscal: '.$_POST[notaFiscal].' &#10;';
$post['informacoesComplementares'] .= 'Modalidade: '.$_POST[modalidade].' &#10;';
$post['informacoesComplementares'] .= 'Obs: '.$_POST[observacao].' &#10;';


 
$post['nomeDestinatario']   = $_POST[nomeDestinatario];

// $post['informacoesComplementares'] .= 'Nome dest.: '.$_POST[nomeDestinatario].' &#10;';
$post['informacoesComplementares'] .= 'CNPJ dest.: '.$_POST[cnpjDestinatario].' &#10;';
$post['informacoesComplementares'] .= 'Endereço dest.: '.$_POST[endereco].' &#10;';
$post['informacoesComplementares'] .= 'Bairro dest.: '.$_POST[bairro].' &#10;';
$post['informacoesComplementares'] .= 'Cidade dest.: '.$_POST[cidade].' &#10;';
$post['informacoesComplementares'] .= 'Estado dest.; '.$_POST[estadoDestinatario].' &#10;';
$post['informacoesComplementares'] .= 'CEP dest.: '.$_POST[cepDestinatario].' &#10;';
$post['informacoesComplementares'] .= 'Telefone dest.: '.$_POST[telefone].' &#10;';


$post['contato']   = $_POST[contato];

// $post['informacoesComplementares'] .= 'Contato dest.: '.$_POST[contato].' &#10;';


// $t = json_encode($post, JSON_UNESCAPED_UNICODE);



    $url_dest                           = "http://gwfiscal.gwcloud.com.br/webresources/v2/servicosGW/solicitarColeta/";
    $headers                            = array('Content-Type: application/json', 'token:'.$token);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url_dest);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post, JSON_UNESCAPED_UNICODE));
    
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0); 
    $result = curl_exec($ch); 


     // echo $result;
   



     $arrResp = json_decode($result, true); // o teu array criado a partir do json de resposta

      // print_r($arrResp);

     $emailRemetente =  $_POST[emailRemetente];
     $numeroColeta = $arrResp[numeroColeta];
    $mensagem = $arrResp[mensagem];
     

    
?>
 <script>
    alert('<? echo $mensagem; ?> - Coleta nº <? echo $numeroColeta; ?>');
  //  window.location.href = "index.html";

</script>




                        
                    <center>
                    <h4><? echo $mensagem; ?>. 
                        <br> Coleta nº <? echo $numeroColeta; ?><br><br>
                        <h4>
                       <h5>
                           <!---
                        <br> Os dados da solicitação foram enviados para o email do remetente:  <? // echo $emailRemetente; ?><br>
-->
                    </h5>
                    </center>


<?php
// include('send-mail-coleta.php');
?>



                        
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->
