<?php

//error_reporting(E_ALL);
error_reporting(E_STRICT);

date_default_timezone_set('America/Toronto');

require_once('phpmailer/class.phpmailer.php');



$nome = "tADEU";
$email = $emailRemetente;

$assunto = 'Rápido Figueiredo - Solicitação de Coleta - $numeroColeta';

$mensagem = 'Recebemos a sua solicitação de Coleta ON LINE, o nº da sua coleta é o $numeroColeta';


//include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded

$mail             = new PHPMailer();

// $body             = file_get_contents('contents.html');


// $body             = eregi_replace("[\]",'',$body);


$body ="

<html>
    <head></head>
    <body>
      <table width='685' border='0'>
        <tr>
          <td height='467' valign='top' bgcolor='#fff'>
            <table width='685' border='0'>
              <tr>
                <td width='37' height='134'>&nbsp;</td>
                <td width='711'><h1><img src='http://rapidofigueiredo.com.br/images/fale-conosco.jpg'></h1></td>
                <td width='37'>&nbsp;</td>
              </tr>
              <tr>
                <td height='203'>&nbsp;</td>    
                <td valign='top' bgcolor='#FFFFFF' style='border:1px solid #333; font-size:14px; line-height:1.3em;padding:27px;font-family:arial;'><br/>
<p><strong> Nome:</strong> $nome </p><br />
<p><strong> Email:</strong> $email </p><br />
<p><strong> Telefone:</strong> $telefone </p><br />

<p><strong> Mensagem:<br></strong> $mensagem </p>
                
                
                
                </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height='27' colspan='3'>&nbsp;</td>
  </tr>
</table>
</td>
</tr>
</table>
</body>
</html>
";





$mail->IsSMTP(); // telling the class to use SMTP
$mail->Host       = "mail.rapidofigueiredo.com.br"; // SMTP server
$mail->SMTPDebug  = 2;                     // enables SMTP debug information (for testing)
                                           // 1 = errors and messages
                                           // 2 = messages only
$mail->SMTPAuth   = true;                  // enable SMTP authentication
$mail->Host       = "mail.rapidofigueiredo.com.br"; // sets the SMTP server
// $mail->SMTPSecure = 'ssl';
$mail->Port       = 587;                    // set the SMTP port for the GMAIL server
$mail->Username   = "mailer@rapidofigueiredo.com.br"; // SMTP account username
$mail->Password   = "#brasil@197620222628";        // SMTP account password

	
$mail->SMTPOptions = array( 'ssl' => array( 'verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true ) );

$mail->SetFrom('mailer@rapidofigueiredo.com.br', 'Rápido Figueiredo');

// $mail->AddReplyTo("faleconosco@rapidofigueiredo.com.br", "Fale Conosco");

$mail->Subject    = "RÁPIDO FIGUEIREDO - COLETA ON LINE";

// $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

$mail->MsgHTML($body);

$address = $emailRemetente;
$mail->AddAddress($address, 'Fale Conosco');


// $mail->AddAttachment("images/phpmailer.gif");      // attachment
// $mail->AddAttachment("images/phpmailer_mini.gif"); // attachment

if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} else {
  echo "<div class='alert alert-success'>Mensagem enviada!</div>";
}

?>